import React from "react";

export default function GuessingGame() {
    let i = 1;
    return (
        <>
            <meta charSet="UTF-8" />
            <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
            <title>Guess a Word Game JavaScript</title>
            <link rel="stylesheet" href="style.css " />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Document</title>
            <div className="wrapper">
                <h1>Guess the Word</h1>
                <div className="content">
                    <div className="inputs">
                        <input type="text" disabled="" />
                        <input type="text" disabled="" />
                        <input type="text" disabled="" />
                        <input type="text" disabled="" />
                        <input type="text" disabled="" />
                        <input type="text" disabled="" />
                    </div>
                    <div className="details">
                        <p className="hint">
                            Hint: <span>Hint will be shown here</span>
                        </p>
                        <p className="guess-left">
                            {" "}
                            Remaining Guesses: <span> 10</span>
                        </p>
                        <p className="wrong-letter">
                            Wrong letters: <span>a, b, c, d</span>
                        </p>
                    </div>
                </div>
            </div>
        </>

    );
}