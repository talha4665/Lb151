import logo from './logo.svg';
import './App.css';
import { useAuth } from './context/AuthContext';

function App() {
  //get User
  const { user, login, logOut } = useAuth()

  if(!user){
    return (
      <div className="App">
        <button onClick={() => login()}>Login</button>
      </div>
    );
  }

  return (
    
    <div className="App">
      <h1>{user.displayName}</h1>
      <button onClick={logOut}>logOut</button>
      
    </div>

  );
}

export default App;
