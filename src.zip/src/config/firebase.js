import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyBQISQkBeZDbXbkZobIsII4zAq1Ifbxe6A",
    authDomain: "lb-m151.firebaseapp.com",
    projectId: "lb-m151",
    storageBucket: "lb-m151.appspot.com",
    messagingSenderId: "902565983337",
    appId: "1:902565983337:web:897986ccca112e862e9ef8"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

export const firestore = getFirestore(app);

//export const firestore = getFirestore(app)

export default app;